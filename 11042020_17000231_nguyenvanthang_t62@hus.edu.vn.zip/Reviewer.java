package HW2;

public class Reviewer extends BookManager {
	String review;

	public Reviewer(int soLuong, int danhGia, double gia, String tenSach, String review) {
		super(soLuong, danhGia, gia, tenSach);
		this.review = review;
	}
}
