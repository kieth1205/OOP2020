package HW2;

public class Seller extends BookManager {
	public Seller(int soLuong, int danhGia, double gia, String tenSach) {
		super(soLuong, danhGia, gia, tenSach);
		// TODO Auto-generated constructor stub
	}

	int muc;
	int luong;

	public void Seller(int muc, int luong) {
		this.muc = muc;
		this.luong = luong;
		// TODO Auto-generated constructor stub
	}

	public void sellbook(int gia) {
		this.luong += gia * (5 * muc) / 100;
	}

}
