package HW2;

public class BookManager {
	// Todo :
	// Chúng ta cần tạo một chương trình có thể quản lý kho sách
	// - Mỗi cuốn sách có giá ban đầu và số lượng nhất định
	// - Mỗi cuốn sách có cấp đánh giá từ 1 - 5 sao
	// - Cấp đánh giá sao cuốn sách = trung bình các lần đánh giá
	// - Số lượng cuốn sách có thể thay đổi dựa trên việc bán và nhập.
	// - Giá sách được bạn cho người dùng dựa trên công thức sau
	// - Số lượng sách mà lớn hơn 100 => Sale 10%
	// - Số lượng sách mà nhỏ hơn 100 => Sale 20%
	// - Nếu số lượng sách mà > 1000 thì không cho nhập
	// - Chúng ta sử dụng lớp này cho 4 kiểu người dùng
	// - Người bán sách
	// - Người bán sách có nhiều cấp. Từ cấp 1 cho tới cấp 4
	// - Hoa hồng cho người bán sách theo cấp độ từ 20% 15% 10% 5% tương ứng 4 cấp
	// - Người nhập sách
	// - Người mua sách
	// - Người mua sách sẽ được giảm giá thêm 3% nếu đã từng mua sách ở đây
	// - Người review sách

	// Tạo lớp đối tượng về sách có đủ các thông tin cần thiết theo mô tả
	// Sử dụng lớp BookManager.class làm lớp cha, có các phương thức, các biến chung
	// cần thiết
	// cho các lớp con theo yêu cầu của đề bài.
	// Mỗi lớp con có các phương thức riêng biệt cho từng kiểu người dùng
	private int soLuong, danhGia;
	private double gia;
	private String tenSach = "";

	public BookManager(int soLuong, int danhGia, double gia, String tenSach) {
		super();
		this.soLuong = soLuong;
		this.danhGia = danhGia;
		this.gia = gia;
		this.tenSach = tenSach;
		sale();
	}

	private void sale() {
		// TODO Auto-generated method stub
		if (soLuong > 100) {
			this.gia = this.gia * 90 / 100;
		} else
			this.gia = this.gia * 80 / 100;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

	public int getDanhGia() {
		return danhGia;
	}

	public void setDanhGia(int danhGia) {
		this.danhGia = danhGia;
	}

	public double getGia() {
		return gia;
	}

	public void setGia(double gia) {
		this.gia = gia;
	}

	public String getTenSach() {
		return tenSach;
	}

	public void setTenSach(String tenSach) {
		this.tenSach = tenSach;
	}

}
