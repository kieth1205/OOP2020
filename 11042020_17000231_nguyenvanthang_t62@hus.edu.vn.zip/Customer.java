package HW2;

import java.util.ArrayList;

public class Customer {
	String Name = "";
	boolean sale = false;
	ArrayList<BookManager> list = new ArrayList<BookManager>();

	public Customer() {
	}

	void SetName(String name) {
		Name = name;
	}

	void check() {
		if (list.size() != 0) {
			sale = true;
		}

	}

	void Buy(BookManager buy) {
		check();
		if (sale) {
			buy.setGia(buy.getGia() * 97 / 100);
		}
		list.add(buy);
	}
}
